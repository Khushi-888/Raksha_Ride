"""
RakshaRide Enhanced - Complete Ride Sharing Platform
Includes: QR Code System, Ride Management, Payment Integration, History Tracking
"""

from flask import Flask, render_template, request, jsonify, session
from flask_cors import CORS
import sqlite3
import hashlib
import secrets
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
import re
import json
import qrcode
import io
import base64
import threading
from PIL import Image
from security_enhancements import (
    encrypt_document, decrypt_document,
    sign_qr_payload, verify_qr_payload,
    generate_unique_id, mask_aadhaar
)
from ai_verification import (
    extract_document_text, compute_face_similarity,
    generate_liveness_challenge, verify_liveness_token,
    run_verification_pipeline
)

app = Flask(__name__)
app.secret_key = 'raksha-ride-enhanced-secret-key-2024'
CORS(app)

# Gmail Configuration (Official Secure Portal)
GMAIL_EMAIL = "riksharide2026@gmail.com"  # ✅ CONFIRMED WORKING
GMAIL_APP_PASSWORD = "evsz tunv eoqi lawu"  # ✅ CONFIRMED PASSCODE
SMTP_SERVER = "smtp.gmail.com"
SMTP_PORT = 587

# Fare Configuration
BASE_FARE = 50  # Base fare in rupees
PER_KM_RATE = 15  # Rate per kilometer
PER_MINUTE_RATE = 2  # Rate per minute

# Database initialization
def init_db():
    conn = sqlite3.connect('database_enhanced.db')
    c = conn.cursor()
    
    # Passengers table
    c.execute('''CREATE TABLE IF NOT EXISTS passengers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        phone TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        profile_image TEXT,
        total_rides INTEGER DEFAULT 0,
        total_spent REAL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # Drivers table
    c.execute('''CREATE TABLE IF NOT EXISTS drivers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        age INTEGER NOT NULL,
        mobile TEXT NOT NULL UNIQUE,
        email TEXT NOT NULL UNIQUE,
        vehicle_number TEXT NOT NULL,
        vehicle_type TEXT DEFAULT 'Car',
        rc_number TEXT NOT NULL,
        password TEXT NOT NULL,
        qr_code TEXT,
        profile_image TEXT,
        upi_id TEXT,
        latitude REAL,
        longitude REAL,
        is_available BOOLEAN DEFAULT 1,
        rating REAL DEFAULT 5.0,
        total_rides INTEGER DEFAULT 0,
        total_earned REAL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # OTP verification table
    c.execute('''CREATE TABLE IF NOT EXISTS otp_verification (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT NOT NULL,
        otp TEXT NOT NULL,
        expiry_time TIMESTAMP NOT NULL,
        attempts INTEGER DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')
    
    # Rides table
    c.execute('''CREATE TABLE IF NOT EXISTS rides (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        passenger_id INTEGER NOT NULL,
        driver_id INTEGER NOT NULL,
        passenger_name TEXT NOT NULL,
        passenger_phone TEXT NOT NULL,
        driver_name TEXT NOT NULL,
        driver_mobile TEXT NOT NULL,
        driver_vehicle TEXT NOT NULL,
        pickup_location TEXT DEFAULT 'Not specified',
        dropoff_location TEXT DEFAULT 'Not specified',
        start_lat REAL,
        start_lng REAL,
        end_lat REAL,
        end_lng REAL,
        route_coordinates TEXT,
        start_time TIMESTAMP,
        end_time TIMESTAMP,
        duration_minutes INTEGER,
        distance_km REAL DEFAULT 0,
        fare REAL,
        status TEXT DEFAULT 'pending',
        payment_status TEXT DEFAULT 'pending',
        payment_method TEXT DEFAULT 'qr_code',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (passenger_id) REFERENCES passengers(id),
        FOREIGN KEY (driver_id) REFERENCES drivers(id)
    )''')
    
    # Payments table
    c.execute('''CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ride_id INTEGER NOT NULL,
        passenger_id INTEGER NOT NULL,
        driver_id INTEGER NOT NULL,
        amount REAL NOT NULL,
        payment_method TEXT DEFAULT 'qr_code',
        payment_qr TEXT,
        upi_id TEXT,
        status TEXT DEFAULT 'pending',
        transaction_id TEXT,
        paid_at TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (ride_id) REFERENCES rides(id),
        FOREIGN KEY (passenger_id) REFERENCES passengers(id),
        FOREIGN KEY (driver_id) REFERENCES drivers(id)
    )''')
    
    # ── Runtime migrations (safe to run every startup) ──────────────────────
    migrations = [
        ('drivers', 'payment_qr_image',    'TEXT'),
        ('drivers', 'unique_id',            'TEXT'),
        ('drivers', 'verification_status',  'TEXT DEFAULT "pending"'),
        ('drivers', 'aadhaar_number',       'TEXT'),
        ('drivers', 'aadhaar_doc',          'TEXT'),
        ('drivers', 'rc_doc',               'TEXT'),
        ('drivers', 'admin_notes',          'TEXT'),
        ('drivers', 'role',                 'TEXT DEFAULT "OWNER"'),
        ('drivers', 'owner_id',             'INTEGER'),
        ('drivers', 'ai_face_score',        'REAL'),
        ('drivers', 'ai_ocr_data',          'TEXT'),
        ('drivers', 'live_selfie',          'TEXT'),
        ('passengers', 'unique_id',         'TEXT'),
        ('passengers', 'aadhaar_number',    'TEXT'),
        ('passengers', 'aadhaar_doc',       'TEXT'),
        ('rides', 'share_token',            'TEXT'),
        ('rides', 'share_token_active',     'INTEGER DEFAULT 0'),
    ]
    for table, col, coltype in migrations:
        try:
            c.execute(f'ALTER TABLE {table} ADD COLUMN {col} {coltype}')
            conn.commit()
        except Exception:
            pass  # Column already exists

    # ── Documents table (Owner-Renter document vault) ─────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS driver_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        driver_id INTEGER NOT NULL,
        uploaded_by INTEGER NOT NULL,
        doc_type TEXT NOT NULL,
        file_data TEXT,
        ocr_extracted TEXT,
        ai_status TEXT DEFAULT 'PENDING',
        ai_score REAL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (driver_id) REFERENCES drivers(id),
        FOREIGN KEY (uploaded_by) REFERENCES drivers(id)
    )''')

    # ── Owner-Renter link requests ────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS renter_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        renter_id INTEGER NOT NULL,
        owner_email TEXT NOT NULL,
        owner_id INTEGER,
        status TEXT DEFAULT 'PENDING',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (renter_id) REFERENCES drivers(id)
    )''')

    # ── Admins table ─────────────────────────────────────────────────────────
    c.execute('''CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT NOT NULL UNIQUE,
        password TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )''')

    # ── Seed default admin if none exists ────────────────────────────────────
    c.execute('SELECT COUNT(*) FROM admins')
    if c.fetchone()[0] == 0:
        import hashlib as _hl
        default_pw = _hl.sha256(b'admin@RakshaRide2024').hexdigest()
        c.execute("INSERT INTO admins (username, password) VALUES (?, ?)",
                  ('admin', default_pw))
        print("[OK] Default admin created -> username: admin | password: admin@RakshaRide2024")

    conn.commit()
    conn.close()
    print("[OK] Enhanced database initialized successfully!")

# Initialize database on startup
init_db()

# Helper functions
def hash_password(password):
    """Hash password using SHA256"""
    return hashlib.sha256(password.encode()).hexdigest()

def generate_otp():
    """Generate 6-digit OTP"""
    return ''.join([str(secrets.randbelow(10)) for _ in range(6)])

def generate_driver_qr_code(driver_id, driver_name, vehicle_number, mobile):
    """Generate HMAC-signed, time-limited QR code for driver"""
    try:
        # Create signed payload
        qr_data = sign_qr_payload(driver_id, driver_name, vehicle_number, mobile)
        qr_json = json.dumps(qr_data)

        # Generate QR code image
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=4,
        )
        qr.add_data(qr_json)
        qr.make(fit=True)

        img = qr.make_image(fill_color="#1a1a2e", back_color="white")
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode()

        return f"data:image/png;base64,{img_str}", qr_json

    except Exception as e:
        print(f"Error generating QR code: {str(e)}")
        return None, None

def generate_payment_qr_code(ride_id, amount, driver_name, upi_id=None):
    """Generate payment QR code"""
    try:
        # Create payment data
        if upi_id:
            # UPI payment string format
            payment_data = f"upi://pay?pa={upi_id}&pn={driver_name}&am={amount}&cu=INR&tn=RakshaRide Payment for Ride {ride_id}"
        else:
            # Generic payment data
            payment_data = {
                'type': 'payment',
                'ride_id': ride_id,
                'amount': amount,
                'driver': driver_name,
                'timestamp': datetime.now().isoformat()
            }
            payment_data = json.dumps(payment_data)
        
        # Generate QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=10,
            border=4,
        )
        qr.add_data(payment_data)
        qr.make(fit=True)
        
        # Create image
        img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert to base64
        buffered = io.BytesIO()
        img.save(buffered, format="PNG")
        img_str = base64.b64encode(buffered.getvalue()).decode()
        
        return f"data:image/png;base64,{img_str}"
        
    except Exception as e:
        print(f"Error generating payment QR: {str(e)}")
        return None

def calculate_fare(duration_minutes, distance_km=0):
    """Calculate ride fare"""
    fare = BASE_FARE + (distance_km * PER_KM_RATE) + (duration_minutes * PER_MINUTE_RATE)
    return round(fare, 2)

def send_email_otp(to_email, otp):
    """Send OTP via Gmail SMTP (with better error handling)"""
    try:
        # Clean the app password (remove spaces and dashes)
        clean_password = GMAIL_APP_PASSWORD.replace(" ", "").replace("-", "")
        
        message = MIMEMultipart()
        message["From"] = f"RakshaRide <{GMAIL_EMAIL}>"
        message["To"] = to_email
        message["Subject"] = "RakshaRide OTP Verification"
        
        body = f"""Hello,

Your RakshaRide OTP verification code is:

    {otp}

This OTP is valid for 5 minutes.

⚠️ Do not share this code with anyone.

Best regards,
RakshaRide Team
"""
        message.attach(MIMEText(body, "plain"))
        
        # Connect to Gmail SMTP server
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=30)  # High timeout for reliability
        server.set_debuglevel(1)  # ENABLED for diagnostics as per user request
        server.starttls()
        
        # Login with credentials
        server.login(GMAIL_EMAIL, clean_password)
        
        # Send email
        server.send_message(message)
        server.quit()
        
        print(f"✅ Email sent successfully to {to_email}")
        return True, "OTP sent successfully"
        
    except smtplib.SMTPAuthenticationError as e:
        error_msg = f"Gmail authentication failed. Please check your App Password or 2-Step Verification settings. Current Email: {GMAIL_EMAIL}"
        print(f"❌ {error_msg}")
        print(f"   RAW ERROR: {str(e)}")
        return False, error_msg
        
    except smtplib.SMTPException as e:
        error_msg = f"SMTP error during delivery: {str(e)}"
        print(f"❌ {error_msg}")
        return False, error_msg
        
    except Exception as e:
        error_msg = f"Critical Email System Failure: {str(e)}"
        print(f"❌ {error_msg}")
        return False, error_msg

def is_valid_email(email):
    """Validate email format"""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return re.match(pattern, email) is not None

# Routes
@app.route('/')
def index():
    return render_template('index_govt.html')

@app.route('/dashboard/passenger')
def passenger_dashboard():
    if 'user_id' not in session or session.get('user_type') != 'passenger':
        return render_template('login_govt.html', type='passenger')
    return render_template('dashboard_passenger.html')

@app.route('/dashboard/driver')
def driver_dashboard():
    if 'user_id' not in session or session.get('user_type') != 'driver':
        return render_template('login_govt.html', type='driver')
    return render_template('dashboard_driver_beautiful.html')

@app.route('/login/passenger')
def login_passenger_page():
    return render_template('login_govt.html', type='passenger')

@app.route('/login/driver')
def login_driver_page():
    return render_template('login_govt.html', type='driver')

@app.route('/register/passenger')
def register_passenger_page():
    return render_template('register_govt.html', type='passenger')

@app.route('/register/driver')
def register_driver_page():
    return render_template('register_govt.html', type='driver')

# Continue in next part...

# ============================================================================
# Authentication APIs (Same as before, enhanced)
# ============================================================================

@app.route('/api/send_otp', methods=['POST'])
def send_otp():
    """Send OTP to email - Production Mode (Email Only)"""
    try:
        data = request.get_json()
        email = data.get('email', '').strip()
        
        if not email or not is_valid_email(email):
            return jsonify({"success": False, "message": "Invalid email address"}), 400
        
        otp = generate_otp()
        expiry_time = datetime.now() + timedelta(minutes=5)
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        # Check if already registered
        c.execute("SELECT id FROM passengers WHERE email = ?", (email,))
        if c.fetchone():
            conn.close()
            return jsonify({"success": False, "message": "Email is already registered as a passenger. Please login."}), 400
            
        c.execute("SELECT id FROM drivers WHERE email = ?", (email,))
        if c.fetchone():
            conn.close()
            return jsonify({"success": False, "message": "Email is already registered as a driver. Please login."}), 400
            
        c.execute("DELETE FROM otp_verification WHERE email = ?", (email,))
        c.execute("""INSERT INTO otp_verification (email, otp, expiry_time, attempts) 
                     VALUES (?, ?, ?, 0)""", (email, otp, expiry_time))
        conn.commit()
        conn.close()
        
        # Send email
        email_success, email_message = send_email_otp(email, otp)
        
        if email_success:
            # SUCCESS: Email sent - Don't show OTP in response
            print(f"✅ SECURITY LOG: Registration OTP sent to ACTUAL email: {email}")
            return jsonify({
                "success": True, 
                "message": f"Official verification code sent to {email}. Check your inbox.",
                "email_sent": True
            })
        else:
            # FAILURE: If email fails, the process stops (Govt Standard)
            print(f"\n{'!'*60}")
            print(f"❌ DELIVERY FAILURE to {email}")
            print(f"❌ Error Detail: {email_message}")
            print(f"{'!'*60}\n")
            
            return jsonify({
                "success": False, 
                "message": "Electronic delivery failed. Please ensure your email is correct and try again.",
                "email_sent": False
            }), 500
            
            
    except Exception as e:
        print(f"❌ Error in send_otp: {str(e)}")
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/verify_otp', methods=['POST'])
def verify_otp():
    """Verify OTP"""
    try:
        data = request.get_json()
        email = data.get('email', '').strip()
        otp = data.get('otp', '').strip()
        
        if not email or not otp:
            return jsonify({"success": False, "message": "Email and OTP required"}), 400
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        c.execute("""SELECT otp, expiry_time, attempts 
                     FROM otp_verification WHERE email = ?""", (email,))
        result = c.fetchone()
        
        if not result:
            conn.close()
            return jsonify({"success": False, "message": "OTP not found"}), 404
        
        stored_otp, expiry_time_str, attempts = result
        
        try:
            expiry_time = datetime.fromisoformat(expiry_time_str.replace(' ', 'T'))
        except:
            expiry_time = datetime.strptime(expiry_time_str, '%Y-%m-%d %H:%M:%S.%f')
        
        if datetime.now() > expiry_time:
            c.execute("DELETE FROM otp_verification WHERE email = ?", (email,))
            conn.commit()
            conn.close()
            return jsonify({"success": False, "message": "OTP expired"}), 400
        
        if attempts >= 3:
            c.execute("DELETE FROM otp_verification WHERE email = ?", (email,))
            conn.commit()
            conn.close()
            return jsonify({"success": False, "message": "Too many attempts"}), 400
        
        if otp != stored_otp:
            c.execute("UPDATE otp_verification SET attempts = attempts + 1 WHERE email = ?", (email,))
            conn.commit()
            remaining = 3 - (attempts + 1)
            conn.close()
            return jsonify({"success": False, "message": f"Invalid OTP. {remaining} attempts remaining"}), 400
        
        c.execute("DELETE FROM otp_verification WHERE email = ?", (email,))
        conn.commit()
        conn.close()
        
        return jsonify({"success": True, "message": "OTP verified successfully"})
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/register_passenger', methods=['POST'])
def register_passenger():
    """Register new passenger with unique ID"""
    try:
        data = request.get_json()
        name = data.get('name', '').strip()
        phone = data.get('phone', '').strip()
        email = data.get('email', '').strip()
        password = data.get('password', '').strip()
        aadhaar_number = data.get('aadhaar_number', '').strip()
        aadhaar_doc = data.get('aadhaar_doc', '')

        if not all([name, phone, email, password]):
            return jsonify({"success": False, "message": "All fields required"}), 400

        if not is_valid_email(email):
            return jsonify({"success": False, "message": "Invalid email"}), 400

        if len(password) < 6:
            return jsonify({"success": False, "message": "Password must be 6+ characters"}), 400

        hashed_password = hash_password(password)
        unique_id = generate_unique_id('PSR')
        enc_aadhaar = encrypt_document(aadhaar_doc) if aadhaar_doc else None

        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        try:
            c.execute("SELECT id FROM passengers WHERE email = ?", (email,))
            if c.fetchone():
                conn.close()
                return jsonify({"success": False, "message": "Email is already registered"}), 400

            c.execute("SELECT id FROM passengers WHERE phone = ?", (phone,))
            if c.fetchone():
                conn.close()
                return jsonify({"success": False, "message": "Mobile number is already registered"}), 400

            c.execute("""INSERT INTO passengers
                         (name, phone, email, password, unique_id, aadhaar_number, aadhaar_doc)
                         VALUES (?, ?, ?, ?, ?, ?, ?)""",
                      (name, phone, email, hashed_password, unique_id, aadhaar_number, enc_aadhaar))
            conn.commit()
            passenger_id = c.lastrowid
            conn.close()

            return jsonify({
                "success": True,
                "message": "Account created successfully!",
                "user_id": passenger_id,
                "unique_id": unique_id
            })
        except sqlite3.IntegrityError:
            conn.close()
            return jsonify({"success": False, "message": "Identity collision. Please verify your details."}), 400

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/register_driver', methods=['POST'])
def register_driver():
    """Register new driver with unique ID and document storage"""
    try:
        data = request.get_json()
        name = data.get('name', '').strip()
        age = data.get('age')
        mobile = data.get('mobile', '').strip()
        email = data.get('email', '').strip()
        vehicle_number = data.get('vehicle_number', '').strip()
        vehicle_type = data.get('vehicle_type', 'Car').strip()
        rc_number = data.get('rc_number', '').strip()
        password = data.get('password', '').strip()
        aadhaar_number = data.get('aadhaar_number', '').strip()
        aadhaar_doc = data.get('aadhaar_doc', '')   # base64 data URI
        rc_doc = data.get('rc_doc', '')             # base64 data URI

        if not all([name, age, mobile, email, vehicle_number, rc_number, password]):
            return jsonify({"success": False, "message": "All fields required"}), 400

        if not is_valid_email(email):
            return jsonify({"success": False, "message": "Invalid email"}), 400

        if len(password) < 6:
            return jsonify({"success": False, "message": "Password must be 6+ characters"}), 400

        try:
            age = int(age)
            if age < 18 or age > 70:
                return jsonify({"success": False, "message": "Age must be 18-70"}), 400
        except ValueError:
            return jsonify({"success": False, "message": "Invalid age"}), 400

        hashed_password = hash_password(password)
        unique_id = generate_unique_id('DRV')

        # Encrypt documents before storage
        enc_aadhaar = encrypt_document(aadhaar_doc) if aadhaar_doc else None
        enc_rc = encrypt_document(rc_doc) if rc_doc else None

        # Placeholder QR (driver_id unknown yet)
        qr_image, qr_data = generate_driver_qr_code(0, name, vehicle_number, mobile)

        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        try:
            for col, val, msg in [
                ('email',          email,          'Email is already registered'),
                ('mobile',         mobile,         'Mobile number is already registered'),
                ('vehicle_number', vehicle_number, 'Vehicle number already registered'),
                ('rc_number',      rc_number,      'RC number already registered'),
            ]:
                c.execute(f"SELECT id FROM drivers WHERE {col} = ?", (val,))
                if c.fetchone():
                    conn.close()
                    return jsonify({"success": False, "message": msg}), 400

            c.execute("""INSERT INTO drivers
                         (name, age, mobile, email, vehicle_number, vehicle_type, rc_number,
                          password, qr_code, unique_id, verification_status,
                          aadhaar_number, aadhaar_doc, rc_doc)
                         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?, ?)""",
                      (name, age, mobile, email, vehicle_number, vehicle_type, rc_number,
                       hashed_password, qr_data, unique_id, aadhaar_number, enc_aadhaar, enc_rc))
            conn.commit()
            driver_id = c.lastrowid

            # Regenerate QR with real driver_id (HMAC-signed)
            qr_image, qr_data = generate_driver_qr_code(driver_id, name, vehicle_number, mobile)
            c.execute("UPDATE drivers SET qr_code = ? WHERE id = ?", (qr_data, driver_id))
            conn.commit()
            conn.close()

            return jsonify({
                "success": True,
                "message": "Driver enrolled! Account pending admin verification. You will be notified by email.",
                "user_id": driver_id,
                "unique_id": unique_id
            })
        except sqlite3.IntegrityError:
            conn.close()
            return jsonify({"success": False, "message": "Enrollment collision. One or more fields already exist."}), 400

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/login_passenger', methods=['POST'])
def login_passenger():
    """Passenger login Step 1: Password Check -> Send OTP"""
    try:
        data = request.get_json()
        credential = data.get('credential', '').strip()
        password = data.get('password', '').strip()
        
        if not credential or not password:
            return jsonify({"success": False, "message": "Credentials required"}), 400
        
        hashed_password = hash_password(password)
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        c.execute("""SELECT id, name, email, phone FROM passengers 
                     WHERE (email = ? OR phone = ?) AND password = ?""", 
                   (credential, credential, hashed_password))
        result = c.fetchone()
        
        if result:
            user_id, name, email, phone = result
            
            # Generate and Send OTP
            otp = generate_otp()
            expiry_time = datetime.now() + timedelta(minutes=5)
            
            c.execute("DELETE FROM otp_verification WHERE email = ?", (email,))
            c.execute("""INSERT INTO otp_verification (email, otp, expiry_time, attempts) 
                         VALUES (?, ?, ?, 0)""", (email, otp, expiry_time))
            conn.commit()
            conn.close()
            
            # Send email
            email_success, email_message = send_email_otp(email, otp)
            
            if email_success:
                print(f"✅ SECURITY LOG: Login OTP sent to ACTUAL email: {email}")
                return jsonify({
                    "success": True,
                    "requires_otp": True,
                    "email": email,
                    "message": f"Security verification code sent to {email}. Please check your inbox.",
                    "email_sent": True
                })
            else:
                print(f"❌ LOGIN OTP FAILURE for {email}: {email_message}")
                return jsonify({
                    "success": False,
                    "message": "Verification code delivery failed. Please check your network or email address.",
                    "email_sent": False
                }), 500
        else:
            conn.close()
            return jsonify({"success": False, "message": "Invalid email/phone or password"}), 401
            
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/verify_login_otp_passenger', methods=['POST'])
def verify_login_otp_passenger():
    """Passenger login Step 2: Verify OTP -> Grant Session"""
    try:
        data = request.get_json()
        email = data.get('email', '').strip()
        otp = data.get('otp', '').strip()
        
        if not email or not otp:
            return jsonify({"success": False, "message": "Email and OTP required"}), 400
        
        # Call common verification
        # But here we also need to set the session for the actual user
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        c.execute("SELECT otp, expiry_time FROM otp_verification WHERE email = ?", (email,))
        result = c.fetchone()
        
        if not result or result[0] != otp:
            conn.close()
            return jsonify({"success": False, "message": "Invalid or expired OTP"}), 400
            
        # Clear OTP
        c.execute("DELETE FROM otp_verification WHERE email = ?", (email,))
        
        # Get User Info
        c.execute("SELECT id, name, email, phone, total_rides, total_spent FROM passengers WHERE email = ?", (email,))
        user_info = c.fetchone()
        conn.commit()
        conn.close()
        
        if user_info:
            session['user_id'] = user_info[0]
            session['user_name'] = user_info[1]
            session['user_type'] = 'passenger'
            return jsonify({
                "success": True, 
                "message": "Login successful!",
                "user": {
                    "id": user_info[0],
                    "name": user_info[1],
                    "email": user_info[2],
                    "phone": user_info[3],
                    "type": "passenger",
                    "total_rides": user_info[4],
                    "total_spent": user_info[5]
                }
            })
        
        return jsonify({"success": False, "message": "User not found after OTP"}), 404
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/login_driver', methods=['POST'])
def login_driver():
    """Driver login Step 1: Accept email OR unique_id, check verification_status"""
    try:
        data = request.get_json()
        credential = data.get('credential', data.get('email', '')).strip()
        password = data.get('password', '').strip()

        if not credential or not password:
            return jsonify({"success": False, "message": "Credentials required"}), 400

        hashed_password = hash_password(password)

        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()

        # Accept email OR unique_id
        c.execute("""SELECT id, name, email, verification_status
                     FROM drivers
                     WHERE (email = ? OR unique_id = ?) AND password = ?""",
                  (credential, credential, hashed_password))
        result = c.fetchone()

        if not result:
            conn.close()
            return jsonify({"success": False, "message": "Invalid credentials"}), 401

        user_id, name, email, verification_status = result

        # Block unverified drivers
        if verification_status == 'pending':
            conn.close()
            return jsonify({"success": False,
                            "message": "Your account is pending admin verification. Please wait for approval email."}), 403
        if verification_status == 'rejected':
            conn.close()
            return jsonify({"success": False,
                            "message": "Your account was rejected. Please contact support."}), 403

        # Generate & send OTP
        otp = generate_otp()
        expiry_time = datetime.now() + timedelta(minutes=5)
        c.execute("DELETE FROM otp_verification WHERE email = ?", (email,))
        c.execute("INSERT INTO otp_verification (email, otp, expiry_time, attempts) VALUES (?, ?, ?, 0)",
                  (email, otp, expiry_time))
        conn.commit()
        conn.close()

        email_success, email_message = send_email_otp(email, otp)
        if email_success:
            return jsonify({"success": True, "requires_otp": True, "email": email,
                            "message": f"Verification code sent to {email}.",
                            "email_sent": True})
        else:
            return jsonify({"success": False,
                            "message": "Verification code delivery failed. Try again.",
                            "email_sent": False}), 500

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/verify_login_otp_driver', methods=['POST'])
def verify_login_otp_driver():
    """Driver login Step 2: Verify OTP -> Grant Session"""
    try:
        data = request.get_json()
        email = data.get('email', '').strip()
        otp = data.get('otp', '').strip()
        
        if not email or not otp:
            return jsonify({"success": False, "message": "Email and OTP required"}), 400
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        c.execute("SELECT otp, expiry_time FROM otp_verification WHERE email = ?", (email,))
        result = c.fetchone()
        
        if not result or result[0] != otp:
            conn.close()
            return jsonify({"success": False, "message": "Invalid or expired OTP"}), 400
            
        # Clear OTP
        c.execute("DELETE FROM otp_verification WHERE email = ?", (email,))
        
        # Get User Info
        c.execute("""SELECT id, name, email, mobile, vehicle_number, vehicle_type, rating, total_rides, total_earned 
                     FROM drivers WHERE email = ?""", (email,))
        user_info = c.fetchone()
        conn.commit()
        conn.close()
        
        if user_info:
            session['user_id'] = user_info[0]
            session['user_name'] = user_info[1]
            session['user_type'] = 'driver'
            return jsonify({
                "success": True, 
                "message": "Login successful!",
                "user": {
                    "id": user_info[0],
                    "name": user_info[1],
                    "email": user_info[2],
                    "mobile": user_info[3],
                    "vehicle_number": user_info[4],
                    "vehicle_type": user_info[5],
                    "type": "driver",
                    "rating": user_info[6],
                    "total_rides": user_info[7],
                    "total_earned": user_info[8]
                }
            })
        
        return jsonify({"success": False, "message": "Driver not found after OTP"}), 404
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# Continue with ride management APIs in next part...

# ============================================================================
# QR Code & Driver APIs
# ============================================================================

@app.route('/api/get_driver_qr', methods=['GET'])
def get_driver_qr():
    """Get driver's QR code"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        
        driver_id = session['user_id']
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("SELECT name, vehicle_number, mobile, qr_code FROM drivers WHERE id = ?", (driver_id,))
        result = c.fetchone()
        conn.close()
        
        if not result:
            return jsonify({"success": False, "message": "Driver not found"}), 404
        
        name, vehicle_number, mobile, qr_data = result
        
        # Generate QR image
        qr_image, _ = generate_driver_qr_code(driver_id, name, vehicle_number, mobile)
        
        return jsonify({
            "success": True,
            "qr_image": qr_image,
            "qr_data": qr_data,
            "driver": {
                "id": driver_id,
                "name": name,
                "vehicle": vehicle_number,
                "mobile": mobile
            }
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/scan_driver_qr', methods=['POST'])
def scan_driver_qr():
    """Scan driver QR — verify HMAC signature and expiry"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'passenger':
            return jsonify({"success": False, "message": "Unauthorized"}), 401

        data = request.get_json()
        qr_data_str = data.get('qr_data', '')
        if not qr_data_str:
            return jsonify({"success": False, "message": "QR data required"}), 400

        # Verify HMAC + expiry
        is_valid, err_msg, qr_data = verify_qr_payload(qr_data_str)
        if not is_valid:
            return jsonify({"success": False, "message": err_msg}), 400

        if qr_data.get('type') != 'driver':
            return jsonify({"success": False, "message": "Not a driver QR code"}), 400

        driver_id = qr_data.get('driver_id')

        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("""SELECT id, name, mobile, vehicle_number, vehicle_type, rating,
                            total_rides, is_available, verification_status
                     FROM drivers WHERE id = ?""", (driver_id,))
        result = c.fetchone()
        conn.close()

        if not result:
            return jsonify({"success": False, "message": "Driver not found"}), 404

        did, name, mobile, vehicle_number, vehicle_type, rating, total_rides, is_available, vstatus = result

        if vstatus != 'approved':
            return jsonify({"success": False, "message": "Driver not yet verified by admin"}), 403

        if not is_available:
            return jsonify({"success": False, "message": "Driver is currently not available"}), 400

        return jsonify({
            "success": True,
            "message": "✅ Driver identity verified (HMAC OK)",
            "driver": {
                "id": did, "name": name, "mobile": mobile,
                "vehicle_number": vehicle_number, "vehicle_type": vehicle_type,
                "rating": rating, "total_rides": total_rides,
                "is_available": bool(is_available)
            }
        })

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/get_nearby_drivers', methods=['GET'])
def get_nearby_drivers():
    """Get list of available drivers (nearby)"""
    try:
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("""SELECT id, name, vehicle_type, vehicle_number, rating, total_rides, latitude, longitude
                     FROM drivers WHERE is_available = 1""")
        results = c.fetchall()
        conn.close()
        
        drivers = []
        for r in results:
            drivers.append({
                "id": r[0],
                "name": r[1],
                "vehicle_type": r[2],
                "vehicle_number": r[3],
                "rating": r[4],
                "total_rides": r[5],
                "latitude": r[6],
                "longitude": r[7]
            })
        
        return jsonify({"success": True, "drivers": drivers})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/update_driver_location', methods=['POST'])
def update_driver_location():
    """Update driver's current location"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        
        data = request.get_json()
        driver_id = session['user_id']
        lat = data.get('latitude')
        lng = data.get('longitude')
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("UPDATE drivers SET latitude = ?, longitude = ? WHERE id = ?", (lat, lng, driver_id))
        conn.commit()
        conn.close()
        
        return jsonify({"success": True, "message": "Location updated"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/update_upi_id', methods=['POST'])
def update_upi_id():
    """Update driver's UPI ID for payments"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        
        data = request.get_json()
        driver_id = session['user_id']
        upi_id = data.get('upi_id')
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("UPDATE drivers SET upi_id = ? WHERE id = ?", (upi_id, driver_id))
        conn.commit()
        conn.close()
        
        return jsonify({"success": True, "message": "UPI ID updated successfully!"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/start_ride', methods=['POST'])
def start_ride():
    """Start a new ride"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'passenger':
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        
        data = request.get_json()
        driver_id = data.get('driver_id')
        pickup_location = data.get('pickup_location', 'Not specified')
        dropoff_location = data.get('dropoff_location', 'Not specified')
        start_lat = data.get('latitude')
        start_lng = data.get('longitude')
        
        if not driver_id:
            return jsonify({"success": False, "message": "Driver ID required"}), 400
        
        passenger_id = session['user_id']
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        # Get passenger details
        c.execute("SELECT name, phone FROM passengers WHERE id = ?", (passenger_id,))
        passenger_result = c.fetchone()
        
        # Get driver details
        c.execute("SELECT name, mobile, vehicle_number, is_available FROM drivers WHERE id = ?", (driver_id,))
        driver_result = c.fetchone()
        
        if not passenger_result or not driver_result:
            conn.close()
            return jsonify({"success": False, "message": "User not found"}), 404
        
        passenger_name, passenger_phone = passenger_result
        driver_name, driver_mobile, driver_vehicle, is_available = driver_result
        
        if not is_available:
            conn.close()
            return jsonify({"success": False, "message": "Driver is not available"}), 400
        
        # Check if passenger has active ride
        c.execute("SELECT id FROM rides WHERE passenger_id = ? AND status = 'active'", (passenger_id,))
        if c.fetchone():
            conn.close()
            return jsonify({"success": False, "message": "You already have an active ride"}), 400
        
        # Create new ride
        start_time = datetime.now()
        c.execute("""INSERT INTO rides (passenger_id, driver_id, passenger_name, passenger_phone, 
                     driver_name, driver_mobile, driver_vehicle, pickup_location, dropoff_location, 
                     start_lat, start_lng, start_time, status) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active')""",
                   (passenger_id, driver_id, passenger_name, passenger_phone, driver_name, 
                    driver_mobile, driver_vehicle, pickup_location, dropoff_location, 
                    start_lat, start_lng, start_time))
        
        ride_id = c.lastrowid
        
        # Update driver availability
        c.execute("UPDATE drivers SET is_available = 0 WHERE id = ?", (driver_id,))
        
        conn.commit()
        conn.close()
        
        print(f"\n{'='*60}")
        print(f"🚗 RIDE STARTED")
        print(f"Ride ID: {ride_id}")
        print(f"Passenger: {passenger_name}")
        print(f"Driver: {driver_name}")
        print(f"Vehicle: {driver_vehicle}")
        print(f"{'='*60}\n")
        
        return jsonify({
            "success": True,
            "message": "Ride started successfully!",
            "ride": {
                "id": ride_id,
                "passenger_name": passenger_name,
                "driver_name": driver_name,
                "driver_mobile": driver_mobile,
                "driver_vehicle": driver_vehicle,
                "pickup_location": pickup_location,
                "dropoff_location": dropoff_location,
                "start_time": start_time.isoformat(),
                "status": "active"
            }
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/toggle_availability', methods=['POST'])
def toggle_availability():
    """Toggle driver's availability status"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        
        driver_id = session['user_id']
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("UPDATE drivers SET is_available = 1 - is_available WHERE id = ?", (driver_id,))
        c.execute("SELECT is_available FROM drivers WHERE id = ?", (driver_id,))
        is_available = c.fetchone()[0]
        conn.commit()
        conn.close()
        
        return jsonify({"success": True, "is_available": bool(is_available)})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/complete_ride', methods=['POST'])
def complete_ride():
    """Complete a ride"""
    try:
        data = request.get_json()
        ride_id = data.get('ride_id')
        distance_km = data.get('distance_km', 5.0)  # Default 5km if not provided
        
        if not ride_id:
            return jsonify({"success": False, "message": "Ride ID required"}), 400
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        # Get ride details
        c.execute("""SELECT passenger_id, driver_id, start_time, status 
                     FROM rides WHERE id = ?""", (ride_id,))
        result = c.fetchone()
        
        if not result:
            conn.close()
            return jsonify({"success": False, "message": "Ride not found"}), 404
        
        passenger_id, driver_id, start_time_str, status = result
        
        if status != 'active':
            conn.close()
            return jsonify({"success": False, "message": "Ride is not active"}), 400
        
        # Calculate duration and fare
        start_time = datetime.fromisoformat(start_time_str.replace(' ', 'T'))
        end_time = datetime.now()
        duration = end_time - start_time
        duration_minutes = int(duration.total_seconds() / 60)
        
        fare = calculate_fare(duration_minutes, distance_km)
        
        route_coordinates = data.get('route_coordinates', '[]')
        
        # Update ride
        end_lat = data.get('latitude')
        end_lng = data.get('longitude')
        
        c.execute("""UPDATE rides SET end_time = ?, duration_minutes = ?, distance_km = ?, 
                     fare = ?, route_coordinates = ?, end_lat = ?, end_lng = ?, status = 'completed' WHERE id = ?""",
                   (end_time, duration_minutes, distance_km, fare, route_coordinates, end_lat, end_lng, ride_id))
        
        # Update driver availability and stats
        c.execute("""UPDATE drivers SET is_available = 1, total_rides = total_rides + 1, 
                     total_earned = total_earned + ? WHERE id = ?""", (fare, driver_id))
        
        # Update passenger stats
        c.execute("""UPDATE passengers SET total_rides = total_rides + 1, 
                     total_spent = total_spent + ? WHERE id = ?""", (fare, passenger_id))
        
        # Create payment record
        c.execute("""INSERT INTO payments (ride_id, passenger_id, driver_id, amount, status) 
                     VALUES (?, ?, ?, ?, 'pending')""", (ride_id, passenger_id, driver_id, fare))
        payment_id = c.lastrowid
        
        # Get driver name and UPI ID for payment QR
        c.execute("SELECT name, upi_id FROM drivers WHERE id = ?", (driver_id,))
        drv_result = c.fetchone()
        driver_name = drv_result[0]
        upi_id = drv_result[1]
        
        # Generate payment QR
        payment_qr = generate_payment_qr_code(ride_id, fare, driver_name, upi_id)
        c.execute("UPDATE payments SET payment_qr = ? WHERE id = ?", (payment_qr, payment_id))
        
        conn.commit()
        conn.close()
        
        print(f"\n{'='*60}")
        print(f"✅ RIDE COMPLETED")
        print(f"Ride ID: {ride_id}")
        print(f"Duration: {duration_minutes} minutes")
        print(f"Distance: {distance_km} km")
        print(f"Fare: ₹{fare}")
        print(f"{'='*60}\n")
        
        return jsonify({
            "success": True,
            "message": "Ride completed successfully!",
            "ride": {
                "id": ride_id,
                "duration_minutes": duration_minutes,
                "distance_km": distance_km,
                "fare": fare,
                "payment_qr": payment_qr,
                "payment_id": payment_id
            }
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

# Continue with history and payment APIs in next part...

# ============================================================================
# History & Profile APIs
# ============================================================================

@app.route('/api/get_passenger_history', methods=['GET'])
def get_passenger_history():
    """Get passenger ride history"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'passenger':
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        
        passenger_id = session['user_id']
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        c.execute("""SELECT r.id, r.driver_name, r.driver_mobile, r.driver_vehicle, 
                     r.pickup_location, r.dropoff_location, r.start_time, r.end_time, 
                     r.duration_minutes, r.distance_km, r.fare, r.status, r.payment_status,
                     p.status as payment_status_detail, p.paid_at
                     FROM rides r
                     LEFT JOIN payments p ON r.id = p.ride_id
                     WHERE r.passenger_id = ?
                     ORDER BY r.created_at DESC""", (passenger_id,))
        
        rides = []
        for row in c.fetchall():
            rides.append({
                "id": row[0],
                "driver_name": row[1],
                "driver_mobile": row[2],
                "driver_vehicle": row[3],
                "pickup_location": row[4],
                "dropoff_location": row[5],
                "start_time": row[6],
                "end_time": row[7],
                "duration_minutes": row[8],
                "distance_km": row[9],
                "fare": row[10],
                "status": row[11],
                "payment_status": row[12],
                "paid_at": row[14]
            })
        
        conn.close()
        
        return jsonify({
            "success": True,
            "rides": rides,
            "total_rides": len(rides)
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/get_driver_history', methods=['GET'])
def get_driver_history():
    """Get driver ride history"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        
        driver_id = session['user_id']
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        c.execute("""SELECT r.id, r.passenger_name, r.passenger_phone, 
                     r.pickup_location, r.dropoff_location, r.start_time, r.end_time, 
                     r.duration_minutes, r.distance_km, r.fare, r.status, r.payment_status,
                     p.status as payment_status_detail, p.paid_at
                     FROM rides r
                     LEFT JOIN payments p ON r.id = p.ride_id
                     WHERE r.driver_id = ?
                     ORDER BY r.created_at DESC""", (driver_id,))
        
        rides = []
        for row in c.fetchall():
            rides.append({
                "id": row[0],
                "passenger_name": row[1],
                "passenger_phone": row[2],
                "pickup_location": row[3],
                "dropoff_location": row[4],
                "start_time": row[5],
                "end_time": row[6],
                "duration_minutes": row[7],
                "distance_km": row[8],
                "fare": row[9],
                "status": row[10],
                "payment_status": row[11],
                "paid_at": row[13]
            })
        
        conn.close()
        
        return jsonify({
            "success": True,
            "rides": rides,
            "total_rides": len(rides)
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/get_active_ride', methods=['GET'])
def get_active_ride():
    """Get user's active ride"""
    try:
        if 'user_id' not in session:
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        
        user_id = session['user_id']
        user_type = session['user_type']
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        if user_type == 'passenger':
            c.execute("""SELECT id, driver_name, driver_mobile, driver_vehicle, 
                         pickup_location, dropoff_location, start_time 
                         FROM rides WHERE passenger_id = ? AND status = 'active'""", (user_id,))
        else:
            c.execute("""SELECT id, passenger_name, passenger_phone, driver_vehicle,
                         pickup_location, dropoff_location, start_time 
                         FROM rides WHERE driver_id = ? AND status = 'active'""", (user_id,))
        
        result = c.fetchone()
        conn.close()
        
        if not result:
            return jsonify({"success": True, "active_ride": None})
        
        return jsonify({
            "success": True,
            "active_ride": {
                "id": result[0],
                "other_party_name": result[1],
                "other_party_contact": result[2],
                "vehicle": result[3],
                "pickup_location": result[4],
                "dropoff_location": result[5],
                "start_time": result[6]
            }
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/process_payment', methods=['POST'])
def process_payment():
    """Process payment for a ride"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'passenger':
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        
        data = request.get_json()
        payment_id = data.get('payment_id')
        transaction_id = data.get('transaction_id', f"TXN{secrets.token_hex(8).upper()}")
        
        if not payment_id:
            return jsonify({"success": False, "message": "Payment ID required"}), 400
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        # Update payment status
        paid_at = datetime.now()
        c.execute("""UPDATE payments SET status = 'completed', transaction_id = ?, paid_at = ? 
                     WHERE id = ?""", (transaction_id, paid_at, payment_id))
        
        # Update ride payment status
        c.execute("UPDATE rides SET payment_status = 'completed' WHERE id = (SELECT ride_id FROM payments WHERE id = ?)", 
                  (payment_id,))
        
        conn.commit()
        conn.close()
        
        return jsonify({
            "success": True,
            "message": "Payment processed successfully!",
            "transaction_id": transaction_id,
            "paid_at": paid_at.isoformat()
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/get_profile', methods=['GET'])
def get_profile():
    """Get user profile"""
    try:
        if 'user_id' not in session:
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        
        user_id = session['user_id']
        user_type = session['user_type']
        
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        
        if user_type == 'passenger':
            c.execute("""SELECT name, phone, email, total_rides, total_spent, created_at 
                         FROM passengers WHERE id = ?""", (user_id,))
            result = c.fetchone()
            
            if result:
                profile = {
                    "type": "passenger",
                    "name": result[0],
                    "phone": result[1],
                    "email": result[2],
                    "total_rides": result[3],
                    "total_spent": result[4],
                    "member_since": result[5]
                }
        else:
            c.execute("""SELECT name, mobile, email, vehicle_number, vehicle_type, rc_number, 
                         rating, total_rides, total_earned, is_available, created_at 
                         FROM drivers WHERE id = ?""", (user_id,))
            result = c.fetchone()
            
            if result:
                profile = {
                    "type": "driver",
                    "name": result[0],
                    "mobile": result[1],
                    "email": result[2],
                    "vehicle_number": result[3],
                    "vehicle_type": result[4],
                    "rc_number": result[5],
                    "rating": result[6],
                    "total_rides": result[7],
                    "total_earned": result[8],
                    "is_available": bool(result[9]),
                    "member_since": result[10]
                }
        
        conn.close()
        
        if not result:
            return jsonify({"success": False, "message": "Profile not found"}), 404
        
        return jsonify({
            "success": True,
            "profile": profile
        })
        
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/get_driver_payment_qr', methods=['GET'])
def get_driver_payment_qr():
    """Get any driver's payment QR image by driver_id (public, for passenger payment)"""
    try:
        driver_id = request.args.get('driver_id')
        if not driver_id:
            return jsonify({"success": False, "message": "driver_id required"}), 400

        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute('SELECT payment_qr_image, upi_id, name FROM drivers WHERE id = ?', (driver_id,))
        result = c.fetchone()
        conn.close()

        if not result:
            return jsonify({"success": False, "message": "Driver not found"}), 404

        payment_qr_image, upi_id, name = result
        return jsonify({
            "success": True,
            "payment_qr_image": payment_qr_image,
            "upi_id": upi_id,
            "driver_name": name
        })
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/upload_payment_qr', methods=['POST'])
def upload_payment_qr():
    """Upload / update driver's custom payment QR image"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401

        data = request.get_json()
        qr_image = data.get('qr_image', '').strip()  # base64 data URI

        if not qr_image:
            return jsonify({"success": False, "message": "QR image data required"}), 400

        # Basic validation: must be a data URI
        if not qr_image.startswith('data:image/'):
            return jsonify({"success": False, "message": "Invalid image format. Must be a valid image."}), 400

        driver_id = session['user_id']

        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute('UPDATE drivers SET payment_qr_image = ? WHERE id = ?', (qr_image, driver_id))
        conn.commit()
        conn.close()

        return jsonify({"success": True, "message": "Payment QR saved successfully!"})

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/get_payment_qr', methods=['GET'])
def get_payment_qr():
    """Get driver's saved payment QR image"""
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401

        driver_id = session['user_id']

        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute('SELECT payment_qr_image, upi_id, name FROM drivers WHERE id = ?', (driver_id,))
        result = c.fetchone()
        conn.close()

        if not result:
            return jsonify({"success": False, "message": "Driver not found"}), 404

        payment_qr_image, upi_id, name = result

        return jsonify({
            "success": True,
            "payment_qr_image": payment_qr_image,
            "upi_id": upi_id,
            "driver_name": name
        })

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/logout', methods=['POST'])
def logout():
    """Logout user"""
    session.clear()
    return jsonify({"success": True, "message": "Logged out successfully"})


# ============================================================================
# Admin Routes
# ============================================================================

@app.route('/admin')
def admin_login_page():
    if session.get('is_admin'):
        return admin_dashboard_page()
    return render_template('admin_login.html')

@app.route('/admin/dashboard')
def admin_dashboard_page():
    if not session.get('is_admin'):
        return render_template('admin_login.html')
    return render_template('admin_dashboard.html')

@app.route('/api/admin/login', methods=['POST'])
def admin_login():
    """Admin login"""
    try:
        data = request.get_json()
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        hashed = hash_password(password)

        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute('SELECT id, username FROM admins WHERE username = ? AND password = ?',
                  (username, hashed))
        result = c.fetchone()
        conn.close()

        if not result:
            return jsonify({"success": False, "message": "Invalid admin credentials"}), 401

        session['is_admin'] = True
        session['admin_id'] = result[0]
        session['admin_name'] = result[1]
        return jsonify({"success": True, "message": "Admin login successful"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/admin/logout', methods=['POST'])
def admin_logout():
    session.pop('is_admin', None)
    session.pop('admin_id', None)
    session.pop('admin_name', None)
    return jsonify({"success": True})

@app.route('/api/admin/pending_drivers', methods=['GET'])
def admin_pending_drivers():
    """List drivers pending verification"""
    if not session.get('is_admin'):
        return jsonify({"success": False, "message": "Unauthorized"}), 401
    try:
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("""SELECT id, name, age, mobile, email, vehicle_number, vehicle_type,
                            rc_number, unique_id, aadhaar_number, verification_status,
                            admin_notes, created_at
                     FROM drivers
                     ORDER BY CASE verification_status
                         WHEN 'pending' THEN 0 WHEN 'approved' THEN 1 ELSE 2 END,
                         created_at DESC""")
        rows = c.fetchall()
        conn.close()
        drivers = []
        for r in rows:
            drivers.append({
                "id": r[0], "name": r[1], "age": r[2], "mobile": r[3],
                "email": r[4], "vehicle_number": r[5], "vehicle_type": r[6],
                "rc_number": r[7], "unique_id": r[8],
                "aadhaar_masked": mask_aadhaar(r[9] or ''),
                "verification_status": r[10], "admin_notes": r[11],
                "registered_at": r[12]
            })
        return jsonify({"success": True, "drivers": drivers})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/admin/view_doc', methods=['GET'])
def admin_view_doc():
    """Decrypt and return a driver document for admin review"""
    if not session.get('is_admin'):
        return jsonify({"success": False, "message": "Unauthorized"}), 401
    try:
        driver_id = request.args.get('driver_id')
        doc_type = request.args.get('doc_type', 'aadhaar')  # 'aadhaar' or 'rc'
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        col = 'aadhaar_doc' if doc_type == 'aadhaar' else 'rc_doc'
        c.execute(f'SELECT {col}, name FROM drivers WHERE id = ?', (driver_id,))
        row = c.fetchone()
        conn.close()
        if not row or not row[0]:
            return jsonify({"success": False, "message": "Document not found"}), 404
        decrypted = decrypt_document(row[0])
        return jsonify({"success": True, "doc": decrypted, "driver_name": row[1], "doc_type": doc_type})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/admin/approve_driver', methods=['POST'])
def admin_approve_driver():
    """Approve a driver — also regenerates their QR"""
    if not session.get('is_admin'):
        return jsonify({"success": False, "message": "Unauthorized"}), 401
    try:
        data = request.get_json()
        driver_id = data.get('driver_id')
        notes = data.get('notes', '')
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("UPDATE drivers SET verification_status = 'approved', admin_notes = ? WHERE id = ?",
                  (notes, driver_id))
        # Regenerate fresh HMAC QR on approval
        c.execute('SELECT name, vehicle_number, mobile FROM drivers WHERE id = ?', (driver_id,))
        row = c.fetchone()
        if row:
            _, qr_data = generate_driver_qr_code(driver_id, row[0], row[1], row[2])
            c.execute('UPDATE drivers SET qr_code = ? WHERE id = ?', (qr_data, driver_id))
        conn.commit()
        # Notify driver by email
        c.execute('SELECT email, name FROM drivers WHERE id = ?', (driver_id,))
        drv = c.fetchone()
        conn.close()
        if drv:
            send_email_otp.__wrapped__ if hasattr(send_email_otp, '__wrapped__') else None
            try:
                _send_approval_email(drv[0], drv[1], approved=True, notes=notes)
            except Exception:
                pass
        return jsonify({"success": True, "message": "Driver approved and QR regenerated!"})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

@app.route('/api/admin/reject_driver', methods=['POST'])
def admin_reject_driver():
    """Reject a driver"""
    if not session.get('is_admin'):
        return jsonify({"success": False, "message": "Unauthorized"}), 401
    try:
        data = request.get_json()
        driver_id = data.get('driver_id')
        notes = data.get('notes', 'Documents could not be verified.')
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("UPDATE drivers SET verification_status = 'rejected', admin_notes = ? WHERE id = ?",
                  (notes, driver_id))
        conn.commit()
        c.execute('SELECT email, name FROM drivers WHERE id = ?', (driver_id,))
        drv = c.fetchone()
        conn.close()
        if drv:
            try:
                _send_approval_email(drv[0], drv[1], approved=False, notes=notes)
            except Exception:
                pass
        return jsonify({"success": True, "message": "Driver rejected."})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500

def _send_approval_email(to_email: str, name: str, approved: bool, notes: str = ''):
    """Send driver approval/rejection email"""
    status = 'APPROVED ✅' if approved else 'REJECTED ❌'
    action = ('You can now log in to the RakshaRide driver app.'
              if approved else
              f'Reason: {notes}\n\nPlease re-register with correct documents or contact support.')
    body = f"""Dear {name},

Your RakshaRide driver account verification status: {status}

{action}

Thank you,
RakshaRide Admin Team
"""
    msg = MIMEMultipart()
    msg['From'] = f'RakshaRide Admin <{GMAIL_EMAIL}>'
    msg['To'] = to_email
    msg['Subject'] = f'RakshaRide Account Verification — {status}'
    msg.attach(MIMEText(body, 'plain'))
    clean_pw = GMAIL_APP_PASSWORD.replace(' ', '').replace('-', '')
    server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=15)
    server.starttls()
    server.login(GMAIL_EMAIL, clean_pw)
    server.send_message(msg)
    server.quit()

# ============================================================================
# AI Verification & Owner-Renter APIs
# ============================================================================

@app.route('/api/ai/ocr_extract', methods=['POST'])
def ai_ocr_extract():
    """Run OCR on an uploaded document and return extracted fields."""
    try:
        data = request.get_json()
        image_uri = data.get('image', '')
        result = extract_document_text(image_uri)
        return jsonify({"success": True, "ocr": result})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/ai/face_match', methods=['POST'])
def ai_face_match():
    """Compare ID photo vs live selfie and return similarity score."""
    try:
        data = request.get_json()
        id_photo = data.get('id_photo', '')
        selfie   = data.get('selfie', '')
        result = compute_face_similarity(id_photo, selfie)
        return jsonify({"success": True, "face_match": result})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/ai/liveness_challenge', methods=['POST'])
def ai_liveness_challenge():
    """Issue a liveness challenge for anti-spoofing."""
    try:
        session_id = session.get('user_id', secrets.token_hex(8))
        challenge = generate_liveness_challenge(str(session_id))
        return jsonify({"success": True, "challenge": challenge})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/ai/liveness_verify', methods=['POST'])
def ai_liveness_verify():
    """Verify returned liveness token after user completes gesture."""
    try:
        data = request.get_json()
        token     = data.get('token', '')
        completed = data.get('completed_challenge', '')
        ok, msg = verify_liveness_token(token, completed)
        return jsonify({"success": ok, "message": msg})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/ai/full_pipeline', methods=['POST'])
def ai_full_pipeline():
    """
    Complete AI verification pipeline:
      - OCR from Aadhaar/RC image
      - Face match (ID photo vs selfie)
      - Decision: VERIFIED / FLAGGED / REJECTED
      Stores result on the driver record.
    """
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401

        data     = request.get_json()
        id_photo = data.get('id_photo', '')   # Aadhaar image
        selfie   = data.get('selfie', '')     # Live selfie
        doc_type = data.get('doc_type', 'AADHAAR').upper()

        # Run in sequence (parallel via threading if needed)
        ocr_result  = extract_document_text(id_photo)
        face_result = compute_face_similarity(id_photo, selfie)
        pipeline    = run_verification_pipeline(ocr_result, face_result)

        driver_id = session['user_id']

        # Save score & selfie to driver record
        enc_selfie = encrypt_document(selfie) if selfie else None
        ocr_json   = json.dumps(ocr_result)

        new_status = pipeline['status'].lower()  # verified / flagged / rejected
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("""
            UPDATE drivers
            SET ai_face_score = ?, ai_ocr_data = ?, live_selfie = ?,
                verification_status = ?
            WHERE id = ?""",
            (pipeline['score'], ocr_json, enc_selfie, new_status, driver_id))

        # Store in driver_documents vault
        enc_doc = encrypt_document(id_photo) if id_photo else None
        c.execute("""
            INSERT INTO driver_documents
              (driver_id, uploaded_by, doc_type, file_data, ocr_extracted,
               ai_status, ai_score)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (driver_id, driver_id, doc_type, enc_doc,
             ocr_result.get('raw_text', ''),
             pipeline['status'], pipeline['score']))

        conn.commit()

        # If auto-verified, send welcome email in background
        if pipeline['status'] == 'VERIFIED':
            c.execute('SELECT email, name, unique_id FROM drivers WHERE id = ?', (driver_id,))
            drv = c.fetchone()
            conn.close()
            if drv:
                threading.Thread(
                    target=_send_welcome_email,
                    args=(drv[0], drv[1], drv[2]),
                    daemon=True
                ).start()
        else:
            conn.close()

        return jsonify({
            "success": True,
            "pipeline": pipeline
        })
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


def _send_welcome_email(to_email: str, name: str, unique_id: str):
    """Send auto-verified welcome email to driver."""
    try:
        body = f"""Welcome to RakshaRide, {name}!

Your AI verification is complete. You are APPROVED to drive.

Your Driver ID: {unique_id}

You can now log in using your email or Driver ID.

Ride Safe,
RakshaRide Team
"""
        msg = MIMEMultipart()
        msg['From'] = f'RakshaRide <{GMAIL_EMAIL}>'
        msg['To'] = to_email
        msg['Subject'] = f'Welcome to RakshaRide! Your ID: {unique_id}'
        msg.attach(MIMEText(body, 'plain'))
        clean_pw = GMAIL_APP_PASSWORD.replace(' ', '').replace('-', '')
        server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=15)
        server.starttls()
        server.login(GMAIL_EMAIL, clean_pw)
        server.send_message(msg)
        server.quit()
    except Exception as e:
        print(f"[WARN] Welcome email failed: {e}")


# ── Owner-Renter Flow ──────────────────────────────────────────────────────────

@app.route('/api/driver/send_renter_request', methods=['POST'])
def send_renter_request():
    """
    Renter submits their owner's email.
    Creates a pending link request; owner gets a notification.
    """
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401

        data        = request.get_json()
        owner_email = data.get('owner_email', '').strip()
        renter_id   = session['user_id']

        if not owner_email:
            return jsonify({"success": False, "message": "Owner email required"}), 400

        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()

        # Find owner
        c.execute("SELECT id, name FROM drivers WHERE email = ? AND role = 'OWNER'", (owner_email,))
        owner = c.fetchone()

        c.execute("""
            INSERT INTO renter_requests (renter_id, owner_email, owner_id, status)
            VALUES (?, ?, ?, 'PENDING')""",
            (renter_id, owner_email, owner[0] if owner else None))
        conn.commit()

        # Get renter name
        c.execute('SELECT name FROM drivers WHERE id = ?', (renter_id,))
        renter_name = c.fetchone()[0]
        conn.close()

        # Notify owner
        if owner:
            threading.Thread(
                target=_send_renter_notification,
                args=(owner_email, owner[1], renter_name),
                daemon=True
            ).start()
            return jsonify({"success": True, "message": "Request sent to owner! Awaiting approval."})
        else:
            return jsonify({"success": True,
                            "message": "Request logged. Owner not yet registered."})

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/driver/approve_renter', methods=['POST'])
def approve_renter():
    """Owner approves a renter linking request."""
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401

        data       = request.get_json()
        request_id = data.get('request_id')
        owner_id   = session['user_id']

        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()

        # Verify this request belongs to the owner
        c.execute("SELECT renter_id FROM renter_requests WHERE id = ? AND owner_id = ?",
                  (request_id, owner_id))
        row = c.fetchone()
        if not row:
            conn.close()
            return jsonify({"success": False, "message": "Request not found"}), 404

        renter_id = row[0]
        c.execute("UPDATE renter_requests SET status = 'APPROVED' WHERE id = ?", (request_id,))
        c.execute("UPDATE drivers SET owner_id = ?, role = 'RENTER' WHERE id = ?",
                  (owner_id, renter_id))
        conn.commit()
        conn.close()
        return jsonify({"success": True, "message": "Renter linked to your account!"})

    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/driver/renter_requests', methods=['GET'])
def get_renter_requests():
    """Owner fetches pending renter link requests."""
    if 'user_id' not in session or session.get('user_type') != 'driver':
        return jsonify({"success": False, "message": "Unauthorized"}), 401
    try:
        owner_id = session['user_id']
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("""
            SELECT rr.id, d.name, d.email, d.mobile, rr.status, rr.created_at
            FROM renter_requests rr
            JOIN drivers d ON d.id = rr.renter_id
            WHERE rr.owner_id = ?
            ORDER BY rr.created_at DESC""", (owner_id,))
        rows = c.fetchall()
        conn.close()
        return jsonify({"success": True, "requests": [
            {"id": r[0], "name": r[1], "email": r[2], "mobile": r[3],
             "status": r[4], "at": r[5]} for r in rows
        ]})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


def _send_renter_notification(owner_email, owner_name, renter_name):
    try:
        body = f"""Dear {owner_name},

A new driver ({renter_name}) has requested to link to your vehicle on RakshaRide.

Log in to your dashboard to approve or deny this request.

RakshaRide Team
"""
        msg = MIMEMultipart()
        msg['From'] = f'RakshaRide <{GMAIL_EMAIL}>'
        msg['To'] = owner_email
        msg['Subject'] = f'RakshaRide: Renter Link Request from {renter_name}'
        msg.attach(MIMEText(body, 'plain'))
        clean_pw = GMAIL_APP_PASSWORD.replace(' ', '').replace('-', '')
        s = smtplib.SMTP(SMTP_SERVER, SMTP_PORT, timeout=15)
        s.starttls(); s.login(GMAIL_EMAIL, clean_pw)
        s.send_message(msg); s.quit()
    except Exception as e:
        print(f"[WARN] Renter notification failed: {e}")


# ── Live Share Token (Emergency Tracking) ────────────────────────────────────

@app.route('/api/ride/generate_share_token', methods=['POST'])
def generate_share_token():
    """Passenger generates a public share link for their active ride."""
    try:
        if 'user_id' not in session or session.get('user_type') != 'passenger':
            return jsonify({"success": False, "message": "Unauthorized"}), 401

        data    = request.get_json()
        ride_id = data.get('ride_id')
        if not ride_id:
            return jsonify({"success": False, "message": "ride_id required"}), 400

        token = secrets.token_urlsafe(20)
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("""
            UPDATE rides SET share_token = ?, share_token_active = 1
            WHERE id = ? AND passenger_id = ?""",
            (token, ride_id, session['user_id']))
        conn.commit()
        conn.close()

        share_url = f"http://localhost:5000/track/{token}"
        return jsonify({"success": True, "share_token": token, "share_url": share_url,
                        "message": "Share this link with anyone to let them track your ride live."})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/track/<token>')
def public_ride_tracker(token):
    """Public page — no login required — shows live ride status."""
    return render_template('ride_tracker.html', share_token=token)


@app.route('/api/ride/track/<token>', methods=['GET'])
def api_ride_track(token):
    """API for public tracker page to poll ride data."""
    try:
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("""
            SELECT r.id, r.driver_name, r.driver_vehicle, r.driver_mobile,
                   r.pickup_location, r.dropoff_location,
                   r.start_lat, r.start_lng, r.end_lat, r.end_lng,
                   r.status, r.start_time, r.share_token_active,
                   d.latitude, d.longitude, d.verification_status
            FROM rides r
            JOIN drivers d ON d.id = r.driver_id
            WHERE r.share_token = ? AND r.share_token_active = 1""", (token,))
        row = c.fetchone()
        conn.close()
        if not row:
            return jsonify({"success": False, "message": "Invalid or expired share link"}), 404

        return jsonify({"success": True, "ride": {
            "id": row[0], "driver_name": row[1], "driver_vehicle": row[2],
            "driver_mobile": row[3], "pickup_location": row[4],
            "dropoff_location": row[5],
            "start_lat": row[6], "start_lng": row[7],
            "end_lat": row[8], "end_lng": row[9],
            "status": row[10], "start_time": row[11],
            "driver_live_lat": row[13], "driver_live_lng": row[14],
            "driver_verified": row[15] == 'verified'
        }})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/ride/stop_sharing', methods=['POST'])
def stop_sharing():
    """Deactivate share token."""
    try:
        if 'user_id' not in session or session.get('user_type') != 'passenger':
            return jsonify({"success": False, "message": "Unauthorized"}), 401
        data = request.get_json()
        ride_id = data.get('ride_id')
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("UPDATE rides SET share_token_active = 0 WHERE id = ? AND passenger_id = ?",
                  (ride_id, session['user_id']))
        conn.commit(); conn.close()
        return jsonify({"success": True, "message": "Live sharing stopped."})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


# ── Document Vault (Owner-Renter restriction) ─────────────────────────────────

@app.route('/api/driver/upload_document', methods=['POST'])
def upload_driver_document():
    """
    Upload Aadhaar/RC/License to encrypted vault.
    RENTER cannot upload RC — only OWNER can.
    """
    try:
        if 'user_id' not in session or session.get('user_type') != 'driver':
            return jsonify({"success": False, "message": "Unauthorized"}), 401

        data     = request.get_json()
        doc_type = data.get('doc_type', '').upper()
        image    = data.get('image', '')
        uploader_id = session['user_id']

        if not doc_type or not image:
            return jsonify({"success": False, "message": "doc_type and image required"}), 400

        # Renter restriction: cannot upload RC or Insurance
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute('SELECT role FROM drivers WHERE id = ?', (uploader_id,))
        row = c.fetchone()
        if row and row[0] == 'RENTER' and doc_type in ('RC', 'INSURANCE'):
            conn.close()
            return jsonify({"success": False,
                            "message": "Renters cannot upload vehicle RC/Insurance. Contact your vehicle Owner."}), 403

        enc_image  = encrypt_document(image)
        ocr_result = extract_document_text(image)
        ocr_text   = ocr_result.get('raw_text', '')
        doc_number = ocr_result.get('doc_number', '')

        # Detect duplicate doc number
        if doc_number:
            c.execute("SELECT id FROM driver_documents WHERE ocr_extracted LIKE ?",
                      (f'%{doc_number}%',))
            if c.fetchone():
                conn.close()
                return jsonify({"success": False,
                                "message": f"Document number {doc_number} already registered."}), 409

        c.execute("""
            INSERT INTO driver_documents
              (driver_id, uploaded_by, doc_type, file_data, ocr_extracted, ai_status)
            VALUES (?, ?, ?, ?, ?, 'PENDING')""",
            (uploader_id, uploader_id, doc_type, enc_image, ocr_text))
        doc_id = c.lastrowid
        conn.commit(); conn.close()

        return jsonify({
            "success": True,
            "message": f"{doc_type} uploaded and queued for AI verification.",
            "doc_id": doc_id,
            "ocr": {"doc_number": doc_number, "name": ocr_result.get('name'),
                    "dob": ocr_result.get('dob')}
        })
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


@app.route('/api/driver/my_documents', methods=['GET'])
def get_my_documents():
    """List uploaded documents for current driver (no file data, metadata only)."""
    if 'user_id' not in session or session.get('user_type') != 'driver':
        return jsonify({"success": False, "message": "Unauthorized"}), 401
    try:
        driver_id = session['user_id']
        conn = sqlite3.connect('database_enhanced.db')
        c = conn.cursor()
        c.execute("""
            SELECT id, doc_type, ai_status, ai_score, created_at
            FROM driver_documents WHERE driver_id = ?
            ORDER BY created_at DESC""", (driver_id,))
        rows = c.fetchall()
        conn.close()
        return jsonify({"success": True, "documents": [
            {"id": r[0], "doc_type": r[1], "ai_status": r[2],
             "ai_score": r[3], "uploaded_at": r[4]} for r in rows
        ]})
    except Exception as e:
        return jsonify({"success": False, "message": str(e)}), 500


# ============================================================================
# Run Application
# ============================================================================

if __name__ == '__main__':
    print("\n" + "="*70)
    print("  RakshaRide Enhanced + AI Verification Engine")
    print("="*70)
    print(f"  Server: http://localhost:5000")
    print(f"  Admin:  http://localhost:5000/admin")
    print(f"  Track:  http://localhost:5000/track/<share_token>")
    print(f"  Email:  {GMAIL_EMAIL}")
    print("\n  AI Features: OCR | Face Match | Liveness | Owner-Renter | Share Tracking")
    print("="*70 + "\n")
    init_db()
    app.run(debug=True, host='0.0.0.0', port=5000)
