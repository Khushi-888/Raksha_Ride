import sqlite3

def check_db():
    conn = sqlite3.connect('database_enhanced.db')
    c = conn.cursor()
    
    print("--- TABLES ---")
    c.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = c.fetchall()
    for table in tables:
        print(f"Table: {table[0]}")
        c.execute(f"PRAGMA table_info({table[0]})")
        columns = c.fetchall()
        for col in columns:
            print(f"  Column: {col[1]} ({col[2]})")
            
    print("\n--- PASSENGERS DATA ---")
    c.execute("SELECT * FROM passengers")
    rows = c.fetchall()
    for row in rows:
        print(row)
        
    print("\n--- DRIVERS DATA ---")
    c.execute("SELECT * FROM drivers")
    rows = c.fetchall()
    for row in rows:
        print(row)
        
    conn.close()

if __name__ == "__main__":
    check_db()
